package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.TravelAgentDetails;

public interface TravelAgentDetailsRepositoryInterface {

	public TravelAgentDetails getTravalAgentDetailsByAgentId(int agentId);

	public List<TravelAgentDetails> getAllTravalAgentDetails();

}
